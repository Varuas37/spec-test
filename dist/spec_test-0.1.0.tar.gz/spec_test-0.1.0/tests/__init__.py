"""Tests for spec-test."""
